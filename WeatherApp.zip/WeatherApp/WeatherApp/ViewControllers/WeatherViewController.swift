//
//  ViewController.swift
//  WeatherApp
//
//  Created by Наташа Спиридонова on 13.05.2025.
//

import UIKit
import CoreLocation

final class WeatherViewController: UIViewController {
    private let weatherService = WeatherService.shared
    private let locationManager = LocationManager.shared
    
    // MARK: - UI Components
    private lazy var scrollView: UIScrollView = {
        let scrollView = UIScrollView()
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        scrollView.showsVerticalScrollIndicator = false
        return scrollView
    }()
    
    private lazy var contentView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    private lazy var currentWeatherView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = .systemBackground
        view.layer.cornerRadius = 12
        return view
    }()
    
    private lazy var temperatureLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = .systemFont(ofSize: 72, weight: .thin)
        label.textAlignment = .center
        return label
    }()
    
    private lazy var conditionLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = .systemFont(ofSize: 24)
        label.textAlignment = .center
        return label
    }()
    
    private lazy var locationLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = .systemFont(ofSize: 18)
        label.textAlignment = .center
        return label
    }()
    
    private lazy var hourlyCollectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        layout.itemSize = CGSize(width: 80, height: 100)
        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        collectionView.backgroundColor = .clear
        collectionView.showsHorizontalScrollIndicator = false
        collectionView.register(HourlyWeatherCell.self, forCellWithReuseIdentifier: "HourlyCell")
        return collectionView
    }()
    
    private lazy var dailyTableView: UITableView = {
        let tableView = UITableView()
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.backgroundColor = .clear
        tableView.register(DailyWeatherCell.self, forCellReuseIdentifier: "DailyCell")
        tableView.isScrollEnabled = false
        tableView.separatorStyle = .none
        tableView.rowHeight = 60
        tableView.allowsSelection = false
        return tableView
    }()
    
    private lazy var activityIndicator: UIActivityIndicatorView = {
        let indicator = UIActivityIndicatorView(style: .large)
        indicator.translatesAutoresizingMaskIntoConstraints = false
        indicator.hidesWhenStopped = true
        return indicator
    }()
    
    private lazy var errorView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = .systemBackground
        view.isHidden = true
        return view
    }()
    
    private lazy var errorLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.textAlignment = .center
        label.numberOfLines = 0
        return label
    }()
    
    private lazy var retryButton: UIButton = {
        let button = UIButton(type: .system)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitle("Повторить", for: .normal)
        button.addTarget(self, action: #selector(retryButtonTapped), for: .touchUpInside)
        return button
    }()
    
    // MARK: - Properties
    private var hourlyWeather: [Hour] = []
    private var dailyWeather: [ForecastDay] = []
    
    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        setupConstraints()
        setupDelegates()
        fetchWeatherData()
    }
    
    // MARK: - Setup
    private func setupUI() {
        view.backgroundColor = .systemBackground
        
        view.addSubview(scrollView)
        scrollView.addSubview(contentView)
        
        contentView.addSubview(currentWeatherView)
        currentWeatherView.addSubview(temperatureLabel)
        currentWeatherView.addSubview(conditionLabel)
        currentWeatherView.addSubview(locationLabel)
        
        contentView.addSubview(hourlyCollectionView)
        contentView.addSubview(dailyTableView)
        
        view.addSubview(activityIndicator)
        
        view.addSubview(errorView)
        errorView.addSubview(errorLabel)
        errorView.addSubview(retryButton)
    }
    
    private func setupConstraints() {
        NSLayoutConstraint.activate([
            scrollView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            scrollView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            
            contentView.topAnchor.constraint(equalTo: scrollView.topAnchor),
            contentView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor),
            contentView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor),
            contentView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor),
            contentView.widthAnchor.constraint(equalTo: scrollView.widthAnchor),
            
            currentWeatherView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 20),
            currentWeatherView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20),
            currentWeatherView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -20),
            
            temperatureLabel.topAnchor.constraint(equalTo: currentWeatherView.topAnchor, constant: 20),
            temperatureLabel.centerXAnchor.constraint(equalTo: currentWeatherView.centerXAnchor),
            
            conditionLabel.topAnchor.constraint(equalTo: temperatureLabel.bottomAnchor, constant: 8),
            conditionLabel.centerXAnchor.constraint(equalTo: currentWeatherView.centerXAnchor),
            
            locationLabel.topAnchor.constraint(equalTo: conditionLabel.bottomAnchor, constant: 8),
            locationLabel.centerXAnchor.constraint(equalTo: currentWeatherView.centerXAnchor),
            locationLabel.bottomAnchor.constraint(equalTo: currentWeatherView.bottomAnchor, constant: -20),
            
            hourlyCollectionView.topAnchor.constraint(equalTo: currentWeatherView.bottomAnchor, constant: 20),
            hourlyCollectionView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            hourlyCollectionView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
            hourlyCollectionView.heightAnchor.constraint(equalToConstant: 100),
            
            dailyTableView.topAnchor.constraint(equalTo: hourlyCollectionView.bottomAnchor, constant: 20),
            dailyTableView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            dailyTableView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
            dailyTableView.heightAnchor.constraint(equalToConstant: 400),
            dailyTableView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -20),
            
            activityIndicator.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            activityIndicator.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            
            errorView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            errorView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            errorView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            errorView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            
            errorLabel.topAnchor.constraint(equalTo: errorView.topAnchor, constant: 20),
            errorLabel.leadingAnchor.constraint(equalTo: errorView.leadingAnchor, constant: 20),
            errorLabel.trailingAnchor.constraint(equalTo: errorView.trailingAnchor, constant: -20),
            
            retryButton.topAnchor.constraint(equalTo: errorLabel.bottomAnchor, constant: 20),
            retryButton.centerXAnchor.constraint(equalTo: errorView.centerXAnchor),
            retryButton.bottomAnchor.constraint(equalTo: errorView.bottomAnchor, constant: -20)
        ])
    }
    
    private func setupDelegates() {
        hourlyCollectionView.delegate = self
        hourlyCollectionView.dataSource = self
        dailyTableView.delegate = self
        dailyTableView.dataSource = self
    }
    
    // MARK: - Data Fetching
    private func fetchWeatherData() {
        activityIndicator.startAnimating()
        errorView.isHidden = true
        
        locationManager.requestLocation { [weak self] result in
            guard let self else { return }
            
            switch result {
            case .success(let location):
                Task {
                    do {
                        let currentWeather = try await self.weatherService.fetchCurrentWeather(
                            latitude: location.coordinate.latitude,
                            longitude: location.coordinate.longitude
                        )
                        let forecast = try await self.weatherService.fetchForecast(
                            latitude: location.coordinate.latitude,
                            longitude: location.coordinate.longitude
                        )
                        
                        await MainActor.run {
                            self.updateUI(with: currentWeather, forecast: forecast)
                            self.activityIndicator.stopAnimating()
                        }
                    } catch {
                        await MainActor.run {
                            self.showError(error)
                            self.activityIndicator.stopAnimating()
                        }
                    }
                }
            case .failure(let error):
                self.showError(error)
                self.activityIndicator.stopAnimating()
            }
        }
    }
    
    // MARK: - UI Updates
    private func updateUI(with weather: WeatherResponse, forecast: WeatherResponse) {
        temperatureLabel.text = "\(Int(weather.current.tempC))°"
        conditionLabel.text = weather.current.condition.text
        locationLabel.text = "\(weather.location.name), \(weather.location.country)"
        
        if let forecastData = forecast.forecast {
            let currentHour = Calendar.current.component(.hour, from: Date())
            hourlyWeather = forecastData.forecastday.first?.hour.filter { hour in
                let hourFormatter = DateFormatter()
                hourFormatter.dateFormat = "yyyy-MM-dd HH:mm"
                if let date = hourFormatter.date(from: hour.time) {
                    let hourNumber = Calendar.current.component(.hour, from: date)
                    return hourNumber >= currentHour
                }
                return false
            } ?? []
            
            dailyWeather = Array(forecastData.forecastday.prefix(7))
            
            hourlyCollectionView.reloadData()
            dailyTableView.reloadData()
        }
    }
    
    private func showError(_ error: Error) {
        errorLabel.text = "Произошла ошибка: \(error.localizedDescription)"
        errorView.isHidden = false
    }
    
    // MARK: - Actions
    @objc private func retryButtonTapped() {
        fetchWeatherData()
    }
}

// MARK: - UICollectionViewDelegate & DataSource
extension WeatherViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        hourlyWeather.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "HourlyCell", for: indexPath) as? HourlyWeatherCell else {
            return UICollectionViewCell()
        }
        
        let hour = hourlyWeather[indexPath.item]
        cell.configure(with: hour)
        return cell
    }
}

// MARK: - UITableViewDelegate & DataSource
extension WeatherViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        dailyWeather.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "DailyCell", for: indexPath) as? DailyWeatherCell else {
            return UITableViewCell()
        }
        
        let day = dailyWeather[indexPath.row]
        cell.configure(with: day)
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        60
    }
}

#Preview() {
    WeatherViewController()
}
