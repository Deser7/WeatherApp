import Foundation
import CoreLocation

enum WeatherError: Error {
    case invalidURL
    case networkError(Error)
    case decodingError(Error)
}

final class WeatherService {
    static let shared = WeatherService()
    private let session: URLSession
    
    private init(session: URLSession = .shared) {
        self.session = session
    }
    
    func fetchCurrentWeather(latitude: Double, longitude: Double) async throws -> WeatherResponse {
        let urlString = WeatherAPI.currentURL.url
            .replacingOccurrences(of: "LAT", with: String(latitude))
            .replacingOccurrences(of: "LON", with: String(longitude))
        return try await fetchWeatherData(from: urlString)
    }
    
    func fetchForecast(latitude: Double, longitude: Double) async throws -> WeatherResponse {
        let urlString = WeatherAPI.forecastUrl.url
            .replacingOccurrences(of: "LAT", with: String(latitude))
            .replacingOccurrences(of: "LON", with: String(longitude))
        return try await fetchWeatherData(from: urlString)
    }
    
    private func fetchWeatherData(from urlString: String) async throws -> WeatherResponse {
        guard let url = URL(string: urlString) else {
            throw WeatherError.invalidURL
        }
        
        do {
            let (data, response) = try await session.data(from: url)
            
            guard let httpResponse = response as? HTTPURLResponse,
                  (200...299).contains(httpResponse.statusCode) else {
                throw WeatherError.networkError(NSError(domain: "", code: -1))
            }
            
            let decoder = JSONDecoder()
            return try decoder.decode(WeatherResponse.self, from: data)
        } catch let error as DecodingError {
            throw WeatherError.decodingError(error)
        } catch {
            throw WeatherError.networkError(error)
        }
    }
} 
